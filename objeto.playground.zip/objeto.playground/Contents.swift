import UIKit

struct Peixe {
    let aguaDoce: Bool
    let venenoso: Bool
    let carnivoro: Bool
    var estado: EstadoPeixe
    
    enum EstadoPeixe {
        case nadando
        case descansando
        case atacando
    }
    
    init(aguaDoce: Bool, venenoso: Bool, carnivoro: Bool) {
        self.aguaDoce = aguaDoce
        self.venenoso = venenoso
        self.carnivoro = carnivoro
        self.estado = .nadando
    }
    
    func executarAcao() {
        switch estado {
        case .nadando:
            print("Estou nadando")
        case .descansando:
            print("Estou descansando")
        case .atacando:
            print("Estou atacando")
        }
    }
}


let tubarao = Peixe(aguaDoce: false, venenoso: false, carnivoro: true)
print(tubarao.executarAcao())
