protocol ControladorAcao {
    func executarAcao()
}

enum EstadoPeixe {
    case nadando
    case descansando
    case atacando
}

protocol Peixe {
    var aguaDoce: Bool { get }
    var venenoso: Bool { get }
    var carnivoro: Bool { get }
    var estado: EstadoPeixe { get set }
}

struct PeixeImpl: Peixe, ControladorAcao {
    let aguaDoce: Bool
    let venenoso: Bool
    let carnivoro: Bool
    var estado: EstadoPeixe
    
    init(aguaDoce: Bool, venenoso: Bool, carnivoro: Bool, estado: EstadoPeixe) {
        self.aguaDoce = aguaDoce
        self.venenoso = venenoso
        self.carnivoro = carnivoro
        self.estado = estado
    }
    
    func executarAcao() {
        switch estado {
        case .nadando:
            print("Estou nadando")
        case .descansando:
            print("Estou descansando")
        case .atacando:
            print("Estou atacando")
        }
    }
}

var tubarao = PeixeImpl(aguaDoce: false, venenoso: false, carnivoro: true, estado: .nadando)
tubarao.executarAcao()
tubarao.estado = .atacando
tubarao.executarAcao()
